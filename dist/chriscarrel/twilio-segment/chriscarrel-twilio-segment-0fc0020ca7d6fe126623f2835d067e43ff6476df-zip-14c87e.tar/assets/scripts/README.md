# Scripts Directory

This directory holds the full version of the plugin's script(s).  The minified (uglified) version(s) is(are) stored in the `dist` folder.
