Releasing
=========

 1. Run `VERSION=X.Y.Z make release` (where X.Y.Z is the new version).

 That's it! Composer will pick up the new tag and you can see the latest version at https://packagist.org/packages/segmentio/analytics-php.
