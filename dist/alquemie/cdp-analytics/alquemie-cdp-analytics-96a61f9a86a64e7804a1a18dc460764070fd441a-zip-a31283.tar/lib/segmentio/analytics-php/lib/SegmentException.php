<?php

declare(strict_types=1);

namespace Segment;

class SegmentException extends \Exception
{
}
