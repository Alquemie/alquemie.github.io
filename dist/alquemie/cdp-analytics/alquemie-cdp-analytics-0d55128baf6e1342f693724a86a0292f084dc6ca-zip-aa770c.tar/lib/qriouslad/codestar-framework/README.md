This is a composer package for [Codestar framework](https://github.com/Codestar/codestar-framework).

Current version: v2.2.8.1