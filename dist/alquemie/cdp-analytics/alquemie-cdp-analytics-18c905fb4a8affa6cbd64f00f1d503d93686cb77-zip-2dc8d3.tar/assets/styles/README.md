# Styles Directory

This directory holds the full version of the plugin's stylesheet(s).  The minified (uglified) version(s) is(are) stored in the `dist` folder.
