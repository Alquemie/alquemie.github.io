<?php

namespace net\authorize\api\contract\v1;

// don't load directly
if ( ! defined( 'ABSPATH' ) ) {
	die();
}

/**
 * Class representing MobileDeviceLoginRequest
 */
class MobileDeviceLoginRequest extends ANetApiRequestType
{


}

