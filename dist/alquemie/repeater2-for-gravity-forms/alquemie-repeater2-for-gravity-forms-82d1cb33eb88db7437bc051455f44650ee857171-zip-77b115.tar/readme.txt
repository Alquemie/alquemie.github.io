=== Repeater2 for Gravity Forms ===
Contributors: butterflymedia
Tags: gravityforms, gravity, forms, form, gravityforms, repeater2, repeat, duplicate, duplication, field, fields
Requires at least: 5.5
Tested up to: 5.7.1
Stable tag: 2.0.2

A Gravity Forms add-on that allows specified groups of fields to be repeated by the user.

== Description ==

A Gravity Forms add-on that allows specified groups of fields to be repeated by the user.
