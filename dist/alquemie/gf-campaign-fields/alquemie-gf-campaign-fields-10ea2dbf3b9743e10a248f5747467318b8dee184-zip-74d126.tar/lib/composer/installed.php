<?php return array(
    'root' => array(
        'pretty_version' => 'dev-master',
        'version' => 'dev-master',
        'type' => 'wordpress-plugin',
        'install_path' => __DIR__ . '/../../',
        'aliases' => array(),
        'reference' => '15d433b5af979298bd4461699930c015d8e04dbf',
        'name' => 'alquemie/gf-campaign-fields',
        'dev' => true,
    ),
    'versions' => array(
        'alquemie/gf-campaign-fields' => array(
            'pretty_version' => 'dev-master',
            'version' => 'dev-master',
            'type' => 'wordpress-plugin',
            'install_path' => __DIR__ . '/../../',
            'aliases' => array(),
            'reference' => '15d433b5af979298bd4461699930c015d8e04dbf',
            'dev_requirement' => false,
        ),
    ),
);
