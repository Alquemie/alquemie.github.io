<?php return array(
    'root' => array(
        'pretty_version' => '2.x-dev',
        'version' => '2.9999999.9999999.9999999-dev',
        'type' => 'wordpress-plugin',
        'install_path' => __DIR__ . '/../../',
        'aliases' => array(),
        'reference' => '08a5d63253af33f65d1b17867e19481b9a4b13c2',
        'name' => 'alquemie/gf-campaign-fields',
        'dev' => true,
    ),
    'versions' => array(
        'alquemie/gf-campaign-fields' => array(
            'pretty_version' => '2.x-dev',
            'version' => '2.9999999.9999999.9999999-dev',
            'type' => 'wordpress-plugin',
            'install_path' => __DIR__ . '/../../',
            'aliases' => array(),
            'reference' => '08a5d63253af33f65d1b17867e19481b9a4b13c2',
            'dev_requirement' => false,
        ),
    ),
);
