=== Gravity Forms Campaign Fields Add-On ===
Contributors: alquemie
Tags: gravity forms, google analytics, marketing
Requires at least: 4.0
Tested up to: 4.8.2
Stable tag: 2.2
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Add hidden fields to capture marketing campaign data in Gravity Forms.

== Description ==

This plugin adds advanced fields to Gravity Forms that collect campaign and device data and attaches the data to form entries.

The plugin can be configured to track first touch or last touch attribution and the campaign query string parameters are customizable.

The plugin currently supports:

* Google Analytics UTM Parameters
* Google AdWords (GCLID and MatchType)
* Device Information (browser, OS, device type)
* Marin (KWID and Creative ID)
* Google Analytics Client ID

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/gf-campaign-fields` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Use the Forms->Settings->Campaign Info screen to configure the plugin

== Frequently Asked Questions ==

= Does this plugin include Gravity Forms? =

No, you must purchase your own license of Gravity Forms


== Screenshots ==

1. The settings screen where you define first/last touch attribution and the query string parameters used to define the values
2. Building a form that contains campaign fields

== Changelog ==
= 2.3.1 =
* Fixed Undefined Constant Error

= 2.3 =
* Updated JS variable names
* Bug fixes

= 2.2.1 =
* <script> closing tag fix

= 2.2 =
* Set UTM_SOURCE as required parameter to set data

= 2.1 =
* Refactored code to used GF_Field_HiddenGroup class
* Moved dependancies to "lib" folder
* Added Google Analytics Client ID field

= 2.0 =
* Added JS-Cookie library
* Refactored Campaign data storage
* Added config for Cookie Lifetime
* Improved first / last touch attribution capabilities
* Fixed WhichBrowser 500 error
* Added Google Tag Manger capabilities

= 1.1.6 =
* Configuration Error fix

= 1.1.5 =
* Fixed JS errors

= 1.1 =
* Fixed readme.txt format issues
* Fixed version inconsistencies

= 1.0.5 =
* The initial release.
