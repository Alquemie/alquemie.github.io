READ ME - Important
***************************************************

Updated: February 13, 2012 7:05 PM

Cursor (pen.cur) image created by Vlastimil Miléř and made available via the Creative Commons Attribution License. 

http://www.rw-designer.com/user/vlasta
http://www.rw-designer.com/cursor-detail/81
http://www.rw-designer.com/licenses