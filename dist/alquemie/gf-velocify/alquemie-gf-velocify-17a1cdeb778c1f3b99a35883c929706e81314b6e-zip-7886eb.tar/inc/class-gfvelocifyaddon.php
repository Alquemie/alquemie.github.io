<?php

GFForms::include_feed_addon_framework();
/**
 *
 */
class AqGFVelocifyAddOn extends GFFeedAddOn {

	protected $_version;
	protected $_min_gravityforms_version = '2.5';
	protected $_slug = 'gf-velocify';
	protected $_path = 'gf-velocify/gf-velocify.php';
	protected $_full_path = __FILE__;
	protected $_title = 'Velocify Lead Capture Add-On';
	protected $_short_title = 'Velocify';

	private static $_instance = null;

	/**
	 * Get an instance of this class.
	 *
	 * @return AqGFVelocifyAddOn
	 */
	public static function get_instance() {
		if ( self::$_instance == null ) {
			self::$_instance = new AqGFVelocifyAddOn();
		}

		return self::$_instance;
	}

	/**
	 * Handles hooks and loading of language files.
	 */
	public function init() {
		$plugin_data = get_plugin_data( dirname( dirname( __FILE__ ) ) . '/gf-velocify.php' );
		$this->_version = $plugin_data['Version'];

		parent::init();
	}


	// # FEED PROCESSING -----------------------------------------------------------------------------------------------
	/**
	 * Process the feed e.g. subscribe the user to a list.
	 *
	 * @param array $feed The feed object to be processed.
	 * @param array $entry The entry object currently being processed.
	 * @param array $form The form object currently being processed.
	 *
	 * @return bool|void
	 */
	public function process_feed( $feed, $entry, $form ) {
		$result = $this->is_simple_condition_met( 'velocify_condition', $form, $entry );
		$this->log_debug( __METHOD__ . '(): feed => ' . print_r( $feed, true ) );

		if ( $result ) {
			// Do something awesome because the rules were met.
			//

			$vProvider = $this->get_plugin_setting( 'velocifyprovider');
			$vClient = $this->get_plugin_setting('velocifyclient');
			$vPostURL = trim($this->get_plugin_setting('velocifyurl'));
			$vLeadOwner = trim($this->get_plugin_setting('velocifyuser'));
			$vAccessKey = trim($this->get_plugin_setting('velocifypw'));

			if (substr($vPostURL, -1) != '?') {
				$vPostURL .= '?';
			}

			if ( ($vClient !== '') && ($vProvider !== '') && ($vPostURL !== '') && ($vLeadOwner !== '') && ($vAccessKey !== '') ) {
				$campaign  = $feed['meta']['velocify_campaign'];
				$camp_field = $this->campaignField($form);
				if ($camp_field !== false) {
					$newCampaign = rgar( $entry, $camp_field);
					$campaign = ($this->validate_int($newCampaign)) ? $newCampaign : $campagin;
				}
				/*
				$campaignOverride = $feed['meta']['velocify_campaign_over'];
				if ($campaignOverride) {
					// Override Default CampaignId
					$origCampaign = $campaign;
					$newCampaign = rgar( $entry, $campaignOverride);
					$campaign = ($this->validate_int($newCampaign)) ? $newCampaign : $campagin;
					if ($campaign != $origCampaign) $this->log_debug( __METHOD__ . '(): Campaign ID changed to ' . $campaign . '(' . $newCampaign . ') from ' . $origCampaign  );
				}
				*/

				$data =  "Client=" . $vClient . "&Provider=" . $vProvider . "&CampaignId=" . $campaign;
				$postcount = 3;

				// $userField = $feed['meta']['velocify_user'];
				$userField = $this->userField($form);
				if ($userField !== false) {
					$userName = rgar( $entry, $userField );
					if ($his->is_valid_email($userName)) {
						$data .= "&User=" . rgar( $entry, $userField );
						$this->log_debug( __METHOD__ . '(): USER ASSIGNED => ' . rgar( $entry, $userField ) );
						$postcount++;
					}
				}

				$vPostURL = $vPostURL . $data;

				// Retrieve the name => value pairs for all fields mapped in the 'mappedFields' field map.
				$field_map = $this->get_field_map_fields( $feed, 'velocifyFieldMap' );
				// Loop through the fields from the field map setting building an array of values to be passed to the third-party service.
				$merge_vars = array();
				foreach ( $field_map as $name => $field_id ) {
					// Get the field value for the specified field id
					$merge_vars[ $name ] = $this->get_field_value( $form, $entry, $field_id );
					if ($merge_vars[$name] !== '') {
						$data .= "&" . $name . "=" . urlencode($merge_vars[$name]);
						$postcount++;
					}
				}

				$dynamic_map = $this->get_dynamic_field_map_fields( $feed, 'additionalMap' );
				foreach ( $dynamic_map as $name => $field_id ) {
					// Get the field value for the specified field id
					$merge_vars[ $name ] = $this->get_field_value( $form, $entry, $field_id );
					if ($merge_vars[$name] !== '') {
						$data .= "&" . $name . "=" . urlencode($merge_vars[$name]);
						$postcount++;
					}
				}

				// Send the values to the third-party service.
				$this->log_debug( 'process_feed(): request => ' . $vPostURL . ' | data => ' . $data );
				
				$result = "NOT POSTED";
				
				$ch = curl_init();
				curl_setopt($ch, CURLOPT_URL, $vPostURL );
				curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
				curl_setopt($ch, CURLOPT_POST, $postcount);
				curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

				try {
						$result = curl_exec($ch);
				}
				catch (Exception $e){
					$this->add_feed_error( 'process_feed(): ERROR: ' . $e->getMessage(), $feed, $entry, $form );
					$this->add_note( $entry['id'], 'process_feed(): ERROR: ' . $e->getMessage(), 'error' );
				}

				curl_close($ch);
				
				$this->log_debug( 'process_feed(): RESULT => ' . $result) ;
				$noteclass = ($result === 'Success') ? 'success' : 'error';
				$this->add_note( $entry['id'], 'Velocify Campaign: ' . $campaign . ' --> Response: ' . $result, $noteclass );
				gform_update_meta( $entry['id'], 'velocifyresp', $result );
			}
			
		}
	}

	protected function campaignField($form) {
		$cid = false;
		foreach ( $form['fields'] as $field) {
			if ($field->type == 'velocify_campaign_id') {
				$cid = $field->id;
				break;
			}
		}

		return $cid;
	}

	protected function userField($form) {
		$cid = false;
		foreach ( $form['fields'] as $field) {
			if ($field->type == 'velocify_user_id') {
				$cid = $field->id;
				break;
			}
		}

		return $cid;
	}

	// # FRONTEND FUNCTIONS --------------------------------------------------------------------------------------------



	// # ADMIN FUNCTIONS -----------------------------------------------------------------------------------------------

	/**
	 * Configures the settings which should be rendered on the add-on settings tab.
	 *
	 * @return array
	 */
	public function plugin_settings_fields() {
		return array(
			array(
				'title'  => esc_html__( 'Velocify Add-On Settings', 'velocifyaddon' ),
				'fields' => array(
					array(
						'name'              => 'velocifyclient',
						'label'             => esc_html__( 'Velocify Client Name', 'velocifyaddon' ),
						'required'          => true,
						'type'              => 'text',
						'class'             => 'small',
						'feedback_callback' => array( $this, 'no_whitespace' ),
					),
					array(
						'name'              => 'velocifyprovider',
						'label'             => esc_html__( 'Lead Provider', 'velocifyaddon' ),
						'required'          => true,
						'type'              => 'text',
						'class'             => 'small',
						'feedback_callback' => array( $this, 'no_whitespace' ),
					),
					array(
						'name'              => 'velocifyurl',
						'label'             => esc_html__( 'Velocify URL', 'velocifyaddon' ),
						'tooltip'			=> esc_html__( 'Desitination URL provided by Velocify', 'velocifyaddon'),
						'required'          => true,
						'type'              => 'text',
						'class'             => 'medium',
						'feedback_callback' => array( $this, 'is_valid_url' ),
					),
					array(
						'name'              => 'velocifyuser',
						'label'             => esc_html__( 'Default Lead Owner', 'velocifyaddon' ),
						'required'          => true,
						'type'              => 'text',
						'class'             => 'medium',
						'feedback_callback' => array( $this, 'no_whitespace' ),
					),
					array(
						'name'              => 'velocifypw',
						'label'             => esc_html__( 'Velocify Password', 'velocifyaddon' ),
						'required'          => true,
						'type'              => 'text',
						'input_type'		=> 'password',
						'class'             => 'medium',
						'feedback_callback' => array( $this, 'no_whitespace' ),
					),
					/*
					array(
						'name'              => 'velocify_campaign_cookie',
						'label'             => esc_html__( 'Campaign Cookie', 'velocifyaddon' ),
						'tooltip'			=> esc_html__( 'Cookie Name to check if the forms Campaign ID should be changed.', 'velocifyaddon'),
						'required'          => false,
						'type'              => 'text',
						'class'             => 'small',
						'feedback_callback' => array( $this, 'no_whitespace' ),
					),
					array(
						'name'              => 'velocify_owner_cookie',
						'label'             => esc_html__( 'Owner Cookie', 'velocifyaddon' ),
						'tooltip'			=> esc_html__( 'Cookie Name to check if the forms Lead Owner should be changed.', 'velocifyaddon'),
						'required'          => false,
						'type'              => 'text',
						'class'             => 'small',
						'feedback_callback' => array( $this, 'no_whitespace' ),
					),
					*/
					array(
						'name'              => 'sitekey',
						'label'             => '',
						'type'              => 'hidden',
						'class'             => 'small',
						'default_value' 	=> $this->generatePrivateKey(),
					),
				)
			));
	}

	private function generatePrivateKey() {
		$hash = WP_HOME . date("Ymd-H:i:s");
		return (md5($hash));
	}
	
	/**
	 * Configures the settings which should be rendered on the Form Settings > Simple Add-On tab.
	 *
	 * @return array
	 */
	public function feed_settings_fields( ) {

		return array(
			array(
				'title'  => esc_html__( 'Velocify Campaign Settings', 'velocifyaddon' ),
				'fields' => array(
					array(
						'label'   => __( 'Campaign Name', 'velocifyaddon' ),
						'required'	=> true,
						'type'    => 'text',
						'name'    => 'velocify_campaign_name',
						'feedback_callback' => array( $this, 'is_valid_setting' ),
					),
					array(
						'label'   => __( 'Default Campaign ID', 'velocifyaddon' ),
						'tooltip' => __('Velocify Campaign ID to use if the form does NOT contain a campaign ID field', 'velocifyaddon' ),
						'required'	=> true,
						'type'    => 'text',
						'name'    => 'velocify_campaign',
						'feedback_callback' => array( $this, 'validate_int' ),
					),
					/*
					array(
						'label'   => __( 'Default Velocify User', 'velocifyaddon' ),
						'tooltip' => __('User that lead will be assigned if the form does NOT contain a user field', 'velocifyaddon' ),
						'required'	=> false,
						'type'    => 'text',
						'name'    => 'velocify_user',
						'feedback_callback' => array( $this, 'is_valid_email' ),
					), */
					/* array(
						'label'   => __( 'Default Velocify User', 'velocifyaddon' ),
						'tooltip' => __('User that lead will be assigned if the form does NOT contain a user field', 'velocifyaddon' ),
						'type'    => 'field_select',
						'name'    => 'velocify_user',
						'args'     => array(
					  		'input_types' => array( 'email', 'hidden' )
						),
						'feedback_callback' => array( $this, 'is_valid_email' ),
					),*/
					array(
						'name'      => 'velocifyFieldMap',
						'label'     => esc_html__( 'Standard Fields', 'velocifyaddon' ),
						'type'      => 'field_map',
						'field_map' => $this->velocify_fields_for_feed_mapping(),

					),
					array(
						'name'                => 'additionalMap',
						'label'               => esc_html__( 'Custom Fields', 'velocifyaddon' ),
						'type'                => 'dynamic_field_map',
						'limit'               => 25,
						'exclude_field_types' => 'creditcard',
						'tooltip'             => esc_html__( 'Custom Velocify post fields based on your specific implementation.  User the field name as defined in the <b>POST</p> URL spreadsheet provided to Velocify.', 'velocifyaddon' ),
						'validation_callback' => array( $this, 'check_dynamic_map' ),
					),
					array(
					    'type'  => 'feed_condition',
					    'name'  => 'velocify_condition',
					    'label' =>  esc_html__( 'Conditional Logic', 'velocifyaddon' ),
					),
				),
			),
		);
	}

/**
 * velocify_fields_for_feed_mapping defines velocify specific fields
 *
 * @return array
 */
	public function velocify_fields_for_feed_mapping() {
	    return array(
			array (
				'name'	=> 'first_name',
				'label' => 'First Name (first_name)',
				'required' => true,
				'field_type'    => array( 'name', 'text', 'hidden' ),
				'default_value' => $this->get_first_field_by_type( 'name', 3 ),
			),
			array (
				'name'	=> 'last_name',
				'label' => 'Last Name (last_name)',
				'required' => true,
				'field_type'    => array( 'name', 'text', 'hidden' ),
				'default_value' => $this->get_first_field_by_type( 'name', 6 ),
			),
			array (
				'name'	=> 'email',
				'label' => 'E-mail Address (email)',
				'required' => true,
				'field_type'    => array( 'email' ),
				'default_value' => $this->get_first_field_by_type( 'email' ),
			),
			array (
				'name'	=> 'home_phone',
				'label' => 'Home Phone (home_phone)',
				'required' => false,
				'field_type'    => array( 'phone', 'text' ),
				'default_value' => $this->get_first_field_by_type( 'phone' ),
			),
			array (
				'name'	=> 'mobile_phone',
				'label' => 'Mobile Phone (mobile_phone)',
				'required' => false,
				'field_type'    => array( 'phone', 'text' ),
			),
			array (
				'name'	=> 'contact_address',
				'label' => 'Mailing Address (contact_address)',
				'required' => false,
				'field_type'    => array( 'address', 'text' ),
				'default_value' => $this->get_first_field_by_type( 'address', 1 ),
			),
			array (
				'name'	=> 'contact_address2',
				'label' => 'Mailing Address 2 (contact_address2)',
				'required' => false,
				'field_type'    => array( 'address', 'text' ),
				'default_value' => $this->get_first_field_by_type( 'address', 2 ),
			),
			array (
				'name'	=> 'contact_city',
				'label' => 'City (contact_city)',
				'required' => false,
				'field_type'    => array( 'address', 'text' ),
				'default_value' => $this->get_first_field_by_type( 'address', 3 ),
			),
			array (
				'name'	=> 'constact_state',
				'label' => 'State (contact_state)',
				'required' => false,
				'field_type'    => array( 'address', 'select', 'text' ),
				'default_value' => $this->get_first_field_by_type( 'address', 4 ),
			),
			array (
				'name'	=> 'contact_zip',
				'label' => 'Zip (contact_zip)',
				'required' => false,
				'field_type'    => array( 'address', 'text' ),
				'default_value' => $this->get_first_field_by_type( 'address', 5 ),
			),
			
	    );
	}


	/**
		 * Configures which columns should be displayed on the feed list page.
		 *
		 * @return array
		 */
		public function feed_list_columns() {
			return array(
				'velocify_campaign_name'  => esc_html__( 'Campaign', 'velocifyaddon' ),
				'velocify_campaign'  => esc_html__( 'Campaign ID', 'velocifyaddon' ),
			);
		}

		/**
		 * Prevent feeds being listed or created if an api key isn't valid.
		 *
		 * @return bool
		 */
		public function can_create_feed() {
			// Get the plugin settings.
			$settings = $this->get_plugin_settings();
			// Access a specific setting e.g. an api key
			$client = trim(rgar( $settings, 'velocifyclient' ));
			$provider = trim(rgar( $settings, 'velocifyprovider' ));
			$url = trim(rgar( $settings, 'velocifyurl' ));
			$userattr = trim(rgar( $settings, 'velocifyuserattr' ));

			$validSettings = false;
			if ( ($client !== '') && ($provider !== '') && ($url !== '') ) {
				$validSettings = true;
			}

			return $validSettings;
		}


	// # SIMPLE CONDITION EXAMPLE --------------------------------------------------------------------------------------


	// # HELPERS -------------------------------------------------------------------------------------------------------

/**
 * Changes the column title of the Velocify Field Map
 *
 * @return string
 */
	public function field_map_title() {
		return esc_html__( 'Velocify Field Name', 'velocifyaddon' );
	}

	/**
	 * The feedback callback for the 'velocify_campaign_name' setting on the plugin settings page and the 'mytext' setting on the form settings page.
	 *
	 * @param string $value The setting value.
	 *
	 * @return bool
	 */
	public function is_valid_setting( $value ) {
		return strlen( $value ) > 2;
	}

	/**
	 * The feedback callback for the 'velocify_campaign_name' setting on the plugin settings page and the 'mytext' setting on the form settings page.
	 *
	 * @param string $value The setting value.
	 *
	 * @return bool
	 */
	public function is_valid_json( $value ) {
		$ob = json_decode($value);
		$rval = true;
		if($ob === null) {
			$rval = false;
		}

		return $rval;
	}

	/**
	 * Determine if value does NOT contain white space character(s)
	 * @param  string  $value
	 * @return boolean
	 */
	public function no_whitespace( $value ) {
    return (!preg_match('/\s+/', $value) && ($value !== ''));
	}

	/**
	 * Determine if value is number
	 * @param  string  $value
	 * @return boolean
	 */
	public function validate_int( $value ) {
    return (preg_match('/^[1-9][0-9]*$/', $value) === 1);
	}

	/**
	 * Determine if value is valid URL string
	 * @param  string  $value
	 * @return boolean
	 */
	public function is_valid_url( $value ) {
    	return (!(filter_var($value, FILTER_VALIDATE_URL) === false) && ($value != '') );
	}

	/**
	 * Determine if value is valid email string
	 * @param  string  $value
	 * @return boolean
	 */
	public function is_valid_email( $value ) {
    	return (!(filter_var($value, FILTER_VALIDATE_EMAIL) === false) && ($value != '') );
	}

	public function check_dynamic_map( $field ) {
		
		$settings = $this->get_posted_settings();
		$metaData = $settings['additionalMap'];
	 
		if ( empty( $metaData ) ) {
			return;
		}
	 
		//loop through metaData and check the key name length (custom_key)
		foreach ( $metaData as $meta ) {
			if ( empty( $meta['custom_key'] ) && ! empty( $meta['value'] ) ) {
				$this->set_field_error( array( 'name' => 'additionalMap' ), esc_html__( "A field has been mapped to a custom key without a name. Please enter a name for the custom key, remove the item, or return the corresponding drop down to 'Select a Field'.", 'velocifyaddon' ) );
				break;
			} elseif ( (!$this->no_whitespace( $meta['custom_key'] ) ) &&  (!empty( $meta['value'] )) ) {
				$this->set_field_error( array( 'name' => 'additionalMap' ), sprintf( esc_html__( 'The name of custom key %s must not contain " " character(s). Please update the post name value.', 'velocifyaddon' ), $meta['custom_key'] ) );
				break;
			}
		}
	}

	public function get_menu_icon() {

		// return 'gform-icon--cog';
		return esc_url( plugins_url( 'img/icon-velocify.png', dirname(__FILE__) ) );
	}

}
