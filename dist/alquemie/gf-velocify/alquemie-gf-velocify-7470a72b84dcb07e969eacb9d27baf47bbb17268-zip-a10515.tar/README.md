# Velocify LeadManager Gravity Form Add-on
This plugin connects Gravity Forms with Velocify Lead Manager