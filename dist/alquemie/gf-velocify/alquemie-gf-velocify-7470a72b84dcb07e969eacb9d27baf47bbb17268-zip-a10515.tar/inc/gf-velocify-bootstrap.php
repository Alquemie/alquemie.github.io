<?php

if ( !defined('ABSPATH') ) {
	header( 'HTTP/1.0 403 Forbidden' );
	die;
}


if ( ! class_exists( 'AQ_Velocify_AddOn_Bootstrap' ) ) :
/**
 *
 */
  class AQ_Velocify_AddOn_Bootstrap {

    public static function load() {
			if ( ! method_exists( 'GFForms', 'include_feed_addon_framework' ) ) {
				return;
			}
		
			require_once( 'fields/class-gf-field-velocify-campaign-id.php' );
			require_once( 'fields/class-gf-field-velocify-user-id.php' );
			
			require_once( 'class-gfvelocifyaddon.php' );
			GFAddOn::register( 'AqGFVelocifyAddOn' );
		
    }

  }
endif;

