<?php
/**
 * Gravity Form AddOn
 *
 * @package     Alquemie\CDP
 * @author      Chris Carrel
 * @license     GPL-3.0+
 *
 * @wordpress-plugin
 * Plugin Name: CDP Analytics - GravityForms AddOn
 * Plugin URI:  https://github.com/alquemie/cdp-analytics/
 * Description: Add 'Form Submitted' Track call and an Identify call to Segment for forms built with GravityForms.
 * Version:     1.0.0
 * Author:      Chris Carrel
 * Author URI:  https://www.linkedin.com/in/chriscarrel/
 * Text Domain: alquemie
 * License:     GPL-3.0+
 * License URI: http://www.gnu.org/licenses/gpl-3.0.txt
 */

namespace Alquemie\CDP;


if ( !defined('ABSPATH') ) {
	header( 'HTTP/1.0 403 Forbidden' );
	die;
}

if ( ! class_exists( 'GravityAddon' ) ) :
	/**
	 *
	 */
	class GravityAddon {
		private $_analytics; 

    public function __construct() {   
			add_action( 'cdp_analytics_loaded', array( $this, 'load') );
		}

		public function load() {
			$this->_analytics = new analytics;

			$this->includes();
			$this->hooks();
		}

		private function includes() {
			require_once dirname( __FILE__ ) . '/lib/autoload.php';
		}

		private function hooks() {
			if (! is_plugin_active( 'gf-campaign-fields/gf-campaign-fields.php' ) ) { 
				add_action('admin_notices', array( $this, 'recommended_notice'  ) );
			}

			if (! is_plugin_active( 'cdp-analytics/cdp-analytics.php' ) ) { 
				add_action('admin_notices', array( $this, 'missing_main_notice'  ) );
			} else {
				add_action( 'wp_enqueue_scripts', array( $this,  'enqueue_webpack_scripts') );
				add_action( 'gform_loaded', array( $this , 'loadGF'), 10, 0 );
				add_action( 'gform_after_save_form', array( $this , 'require_cdp_field' ), 100, 2 );
				add_action( 'gform_after_submission', array( $this, 'post_to_segment') , 10, 2 );
			}
    }

		public function loadGF() {
		
			$files = array(  
				// add the list of files to load here.
				'src/fields/class-gf-field-cdp-analytics.php',
				'src/class-field-processor.php'
				// 'fields/class-gf-field-cdp-userId.php'
			);
		
			foreach ( $files as $file ) {
				require __DIR__ . '/' . $file;
			}
		}

		public function require_cdp_field( $form, $is_new ) {
			$hasField = false;
			foreach ($form['fields'] as $f) {
				if ($f['type'] == 'alqCDPAnalyticsIds') { $hasField = true; }
			}

			if (!$hasField && !$is_new) {
				$form['is_active'] = '1';
				$new_field_id = \GFFormsModel::get_next_field_id( $form['fields'] );
				// if ($is_new) $new_field_id++;
				$properties['type'] = 'alqCDPAnalyticsIds';
				$properties['id']  = $new_field_id;
				$properties['label'] = 'CDP Identifiers';
				$properties['size'] = 'small';
				$field = \GF_Fields::create( $properties );
				$form['fields'][] = $field;
				\GFAPI::update_form( $form );
			}
        
		}

		
		public function post_to_segment( $entry, $form ) {
			$anonId = null;
			$userId = null;

			$traits = array();	
			$properties = array( 
				"form_name" => rgar( $form, 'title' ),
				"description" => rgar( $form, 'description' ),
				"form_id" => rgar( $form, 'id' ),
				"gravity_forms_version" => rgar( $form, 'version' ),
			);

			$context = array(
				"ip" => $entry["ip"],
				"page" => array(
					"url" => $entry["source_url"]
				),
				"userAgent" => $entry["user_agent"]
			);
			// $properties = array("Form Name" => $title, "Form" => $form, "Entry" => $entry);

			$reader = new GravityFields;

			foreach ( $form['fields'] as $field ) {
				if ($field->type == "alqCDPAnalyticsIds" ) {
					$value = rgar( $entry, (string) $field->id );
					$ids = json_decode($value,true);
					$anonId = (isset($ids['anonymous_id'])) ? $ids['anonymous_id'] : null;
					$userId = (isset($ids['user_id'])) ? $ids['user_id'] : null;
				} elseif ($field->type == "aqGoogleAnalytics" ) {
					$value = rgar( $entry, (string) $field->id );
					$campaign = json_decode($value,true);
					$context['campaign'] = array();
					if ((array_key_exists('campaign', $campaign)))  $context['campaign']['name'] = $campaign.campaign;
					if ((array_key_exists('source', $campaign)))  $context['campaign']['source'] = $campaign.source;
					if ((array_key_exists('medium', $campaign)))  $context['campaign']['medium'] = $campaign.medium;
					if ((array_key_exists('content', $campaign)))  $context['campaign']['content'] = $campaign.content;
					if ((array_key_exists('term', $campaign)))  $context['campaign']['term'] = $campaign.term;
					if ((array_key_exists('matchtype', $campaign)))  $context['campaign']['matchtype'] = $campaign.matchtype;
					
					if ((array_key_exists('device', $campaign)))  $context['browser'] = $campaign.device;
					if ((array_key_exists('partner', $campaign)))  $context['lead_source'] = $campaign.partner;
			
					/*
"campaign": {
      "name": "TPS Innovation Newsletter",
      "source": "Newsletter",
      "medium": "email",
      "term": "tps reports",
      "content": "image link"
    },
    "device": {
      "id": "B5372DB0-C21E-11E4-8DFC-AA07A5B093DB",
      "advertisingId": "7A3CBEA0-BDF5-11E4-8DFC-AA07A5B093DB",
      "adTrackingEnabled": true,
      "manufacturer": "Apple",
      "model": "iPhone7,2",
      "name": "maguro",
      "type": "ios",
      "token": "ff15bc0c20c4aa6cd50854ff165fd265c838e5405bfeb9571066395b8c9da449"
    },

    "locale": "en-US",
    "location": {
      "city": "San Francisco",
      "country": "United States",
      "latitude": 40.2964197,
      "longitude": -76.9411617,
      "speed": 0
    },
    "network": {
      "bluetooth": false,
      "carrier": "T-Mobile US",
      "cellular": true,
      "wifi": false
    },
    "os": {
      "name": "iPhone OS",
      "version": "8.1.3"
    },
					*/
				} else {
					$traits = array_merge($traits, $reader->getField($field, $entry, true));
					error_log("Traits: " . print_r($traits, true));
				}	
			}

			\GFCommon::log_debug( 'gform_after_submission: anonomous_id => ' . $anonId . ',  properties => ' . print_r( $properties, true ) );
			$this->_analytics->setAnonymousId($anonId);
			$this->_analytics->setUserId($userId);
			
			$this->_analytics->track('Form Submitted',$properties, $context, $entry["date_created"]);
			$this->_analytics->identify($traits, $context);
		}
		
		/**
		 * Gets this plugin's absolute directory path.
		 *
		 * @since  1.0.0
		 * @ignore
		 * @access private
		 *
		 * @return string
		 */
		public function _get_plugin_directory() {
			return __DIR__;
		}

		/**
		 * Gets this plugin's URL.
		 *
		 * @since  1.0.0
		 * @ignore
		 * @access private
		 *
		 * @return string
		 */
		public function _get_plugin_url() {
			static $plugin_url;

			if ( empty( $plugin_url ) ) {
				$plugin_url = plugins_url( null, __FILE__ );
			}

			return $plugin_url;
		}

		public function enqueue_webpack_scripts() {
  
			$isDevMode = _is_in_development_mode();
			if ($isDevMode) {
					$jsFileURI = $this->_get_plugin_url() . '/src/js/public.js';
			} else {
					$jsFilePath = glob( $this->_get_plugin_directory() . '/dist/js/public.*.js' );
					$jsFileURI = $this->_get_plugin_url() . '/dist/js/' . basename($jsFilePath[0]);
			}
			
			//wp_enqueue_script( $handle, $src, $deps, $ver, $in_footer );
			wp_enqueue_script( 'cdp_analytics_gf', $jsFileURI , array('jquery') , null , true );
		}

		public function missing_main_notice() { ?>
	
			<div class="notice notice-error">
				<p><?php _e('CDP Analytics (GF AddOn) requires the CDP Analytics Plugin', 'cpd-analytics-gf'); ?></p>
			</div>
			
		<?php }

		public function recommended_notice() { ?>
			
			<div class="notice notice-info">
				<p><?php _e('The <a href="https://wordpress.org/plugins/gf-campaign-fields/" target="_blank">GF Campaign Fields</a> plugin will add campaign tracking to your Segment calls.', 'cpd-analytics-gf'); ?></p>
			</div>
			
		<?php }
	}

	$AnalyticsGravityAddon = new GravityAddon();
endif;

