# CDP Analytics - GravityForms Addon

WordPress plugin that adds [GravityForms](https://gravityforms.com) support to [CDP Analytics](https://github.com/Alquemie/cdp-analytics).  

## Installation

1. Install this plugin in your WordPress wp-content/plugins folder
2. Activate the plugin via the WordPress dashboard

### Change Log

#### v1.0.0 - Initial Release
- Implements 'Form Submitted' track call for GravityForm forms
- Implements Identify call to send form data to Segment CDP
