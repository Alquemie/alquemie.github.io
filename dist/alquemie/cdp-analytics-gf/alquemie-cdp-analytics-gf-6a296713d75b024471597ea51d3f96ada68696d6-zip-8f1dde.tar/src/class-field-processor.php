<?php
/**
 * Gravity Forms Field Reader
 *
 * @package     Alquemie\CDP
 * @since       1.0.0
 * @author      Chris Carrel
 * @link        https://alquemie.net
 * @license     GNU-2.0+
 */

namespace Alquemie\CDP;

if ( ! class_exists( 'GravityFields' ) ) :

class GravityFields {
  private $_hasName = false;
  private $_hasAddress = false;
  private $_hasEmail = false;
  private $_hasPhone = false;
  private $_propertyList = array();

	public function __construct() {
    
	}

  public function getField($field, $entry, $useSpec = false) {
    $prop = array();

    switch ($field->type) {
    case "name":
      $prop = $this->name($field, $entry, $useSpec);
      break;
    case "address":
      $prop = $this->address($field, $entry, $useSpec);
      break;
    case "email":
      $prop = $this->email($field, $entry, $useSpec);
      break;
    case "phone":
      $prop = $this->phone($field, $entry, $useSpec);
      break;
    case "password":
    case "creditcard":
    case "captcha":
    case "fileupload":
    case "html":
    case "page":
    case "repeater":
    case "section":
    case "submit":
    case "post_custom_field":
    case "post_category":
    case "post_content":
    case "post_excerpt":
    case "post_image":
    case "post_tags":
    case "post_title":
      // Ignore these field types
      break;
    default:
      $prop = $this->field($field, $entry);
    }

    return $prop;
  }

  private function address($field, $entry, $useSpec = false) {
    $buildLabel = false;
    $inputs = $field->get_entry_inputs();
    error_log("Address: " . print_r($inputs, true));

    if ($useSpec && !$this->_hasAddress) {
      $label = $this->validate_property("address");
      $this->_hasAddress = true;
    } else {
      $label = ($field->adminLabel != "") ? $field->adminLabel : $field->label;
      $label = $this->validate_property($label);
    }

    if ( is_array( $inputs ) ) {
			$street_value  = esc_attr( rgar( $entry, (string) $field->id . '.1' ) );
			$street2_value = esc_attr( rgar( $entry, (string) $field->id . '.2' ) );
			$city_value    = esc_attr( rgar( $entry, (string) $field->id . '.3' ) );
			$state_value   = esc_attr( rgar( $entry, (string) $field->id . '.4' ) );
			$zip_value     = esc_attr( rgar( $entry, (string) $field->id . '.5' ) );
			$country_value = esc_attr( rgar( $entry, (string) $field->id . '.6' ) );
      $country_value = $this->get_country_code($country_value);
      if ($country_value == "US") {
        $state_value = $this->get_us_state_abrv($state_value);
      }
		}

    $prop = array(
      $label => array(
        "street" => $street_value,
        "street2" => $street2_value,
        "city" => $city_value,
        "state" => $state_value ,
        "postalCode" => $zip_value,
        "country" => $country_value
      )
    );

    return $prop;
  }

  private function name($field, $entry, $useSpec = false) {
    $inputs = $field->get_entry_inputs();
    error_log("NAME: " . print_r($inputs, true));

    if ($useSpec && !$this->_hasName) {
      $fullLabel = $this->validate_property("name");
      $firstLabel = $this->validate_property("first_name");
      $lastLabel = $this->validate_property("last_name");
      $this->_hasName = true;
    } else {
      $fullLabel = ($field->adminLabel != "") ? $field->adminLabel : $field->label;

      $firstLabel = ($inputs[1]['name'] != "") ? $input[1]['name'] : $fullLabel . "_" . $inputs[1]['label'];
      $firstLabel = $this->validate_property($label);

      $lastLabel = ($inputs[3]['name'] != "") ? $input[3]['name'] : $fullLabel . "_" . $inputs[3]['label'];
      $lastLabel = $this->validate_property($label);

      $fullLabel = $this->validate_property($fullLabel);
    }


    if ( is_array( $inputs ) ) {
			$prefix = esc_attr( rgar( $entry, (string) $field->id . '.2' ) );
			$first  = esc_attr( rgar( $entry, (string) $field->id . '.3' ) );
			$middle = esc_attr( rgar( $entry, (string) $field->id . '.4' ) );
			$last   = esc_attr( rgar( $entry, (string) $field->id . '.6' ) );
			$suffix = esc_attr( rgar( $entry, (string) $field->id . '.8' ) );
		}
    $fullname = trim($prefix . " " . $first);
    $fullname .= trim(" " . $middle);
    $fullname .= " " . trim($last . " " . $suffix);

    $prop = array(
      $fullLabel => $fullname,
      $firstLabel =>  $first,
      $lastLabel => $last
    );

    return $prop;
  }

  private function email($field, $entry) {
    $props = array();

    if ($useSpec && !$this->_hasEmail) {
      $label = $this->validate_property("email");
      $this->_hasEmail = true;
    } else {
      $label = ($field->adminLabel != "") ? $field->adminLabel : $field->label;
      $label = $this->validate_property($label);
    }

    $value = rgar( $entry, (string) $field->id );
    $props[$label] = $value;
  

    return $props;
  }

  private function phone($field, $entry) {
    $props = array();

    if ($useSpec && !$this->_hasPhone) {
      $label = $this->validate_property("phone");
      $this->_hasPhone = true;
    } else {
      $label = ($field->adminLabel != "") ? $field->adminLabel : $field->label;
      $label = $this->validate_property($label);
    }

    $value = rgar( $entry, (string) $field->id );
    $props[$label] = $value;
  
    return $props;
  }


  private function field($field, $entry) {
    $props = array();

    $inputs = $field->get_entry_inputs();
    error_log("NAME: (" . $field->type . ") " . print_r($inputs, true));
    if ( is_array( $inputs ) ) {
      $fieldName = ($field->adminLabel != "") ? $field->adminLabel : $field->label;
        
      foreach ( $inputs as $input ) {
        $label = ($input['name'] != "") ? $fieldName . "_" . $input['name'] : $fieldName . "_" . $input['label'];
        $label = $this->validate_property($label);
        $value = rgar( $entry, (string) $input['id'] );
        $props[$label] = $value;
      }
    } else {
        $label = ($field->adminLabel != "") ? $field->adminLabel : $field->label;
        $label = $this->validate_property($label);
        $value = rgar( $entry, (string) $field->id );
        $props[$label] = $value;
    }

    return $props;
  }

  private function validate_property($propName) {
    $return = $this->snake_case($propName);

    if ( isset($this->_propertyList[$return]) ) {
      $this->_propertyList[$return]++;
      $return = $return . "_" . $this->_propertyList[$return];
    } else {
      $this->_propertyList[$return] = 1;
    }

    error_log("Validation: " . print_r($this->_propertyList, true ));
    return $return;
  }

  private function snake_case(string $value, ?string $delimiter = null): string
  {
      if (!\ctype_lower($value)) {
          $value = (string) \preg_replace('/\s+/u', '', \ucwords($value));
          $value = (string) \mb_strtolower(\preg_replace(
              '/(.)(?=[A-Z])/u',
              '$1' . ($delimiter ?? '_'),
              $value
          ));
      }

      return $value;
  }

  private function get_us_state_abrv($state) {
    $states = array(
      'AL'=>'Alabama',
      'AK'=>'Alaska',
      'AZ'=>'Arizona',
      'AR'=>'Arkansas',
      'CA'=>'California',
      'CO'=>'Colorado',
      'CT'=>'Connecticut',
      'DE'=>'Delaware',
      'DC'=>'District of Columbia',
      'FL'=>'Florida',
      'GA'=>'Georgia',
      'HI'=>'Hawaii',
      'ID'=>'Idaho',
      'IL'=>'Illinois',
      'IN'=>'Indiana',
      'IA'=>'Iowa',
      'KS'=>'Kansas',
      'KY'=>'Kentucky',
      'LA'=>'Louisiana',
      'ME'=>'Maine',
      'MD'=>'Maryland',
      'MA'=>'Massachusetts',
      'MI'=>'Michigan',
      'MN'=>'Minnesota',
      'MS'=>'Mississippi',
      'MO'=>'Missouri',
      'MT'=>'Montana',
      'NE'=>'Nebraska',
      'NV'=>'Nevada',
      'NH'=>'New Hampshire',
      'NJ'=>'New Jersey',
      'NM'=>'New Mexico',
      'NY'=>'New York',
      'NC'=>'North Carolina',
      'ND'=>'North Dakota',
      'OH'=>'Ohio',
      'OK'=>'Oklahoma',
      'OR'=>'Oregon',
      'PA'=>'Pennsylvania',
      'RI'=>'Rhode Island',
      'SC'=>'South Carolina',
      'SD'=>'South Dakota',
      'TN'=>'Tennessee',
      'TX'=>'Texas',
      'UT'=>'Utah',
      'VT'=>'Vermont',
      'VA'=>'Virginia',
      'WA'=>'Washington',
      'WV'=>'West Virginia',
      'WI'=>'Wisconsin',
      'WY'=>'Wyoming',
    );
  
    $state = ucwords($state);
    return array_search($state, $states);
  }

  private function get_country_code($country) {

      $countries_list = array(
          "AF" => "Afghanistan",
          "AX" => "Aland Islands",
          "AL" => "Albania",
          "DZ" => "Algeria",
          "AS" => "American Samoa",
          "AD" => "Andorra",
          "AO" => "Angola",
          "AI" => "Anguilla",
          "AQ" => "Antarctica",
          "AG" => "Antigua and Barbuda",
          "AR" => "Argentina",
          "AM" => "Armenia",
          "AW" => "Aruba",
          "AU" => "Australia",
          "AT" => "Austria",
          "AZ" => "Azerbaijan",
          "BS" => "Bahamas",
          "BH" => "Bahrain",
          "BD" => "Bangladesh",
          "BB" => "Barbados",
          "BY" => "Belarus",
          "BE" => "Belgium",
          "BZ" => "Belize",
          "BJ" => "Benin",
          "BM" => "Bermuda",
          "BT" => "Bhutan",
          "BO" => "Bolivia",
          "BQ" => "Bonaire, Sint Eustatius and Saba",
          "BA" => "Bosnia and Herzegovina",
          "BW" => "Botswana",
          "BV" => "Bouvet Island",
          "BR" => "Brazil",
          "IO" => "British Indian Ocean Territory",
          "BN" => "Brunei Darussalam",
          "BG" => "Bulgaria",
          "BF" => "Burkina Faso",
          "BI" => "Burundi",
          "KH" => "Cambodia",
          "CM" => "Cameroon",
          "CA" => "Canada",
          "CV" => "Cape Verde",
          "KY" => "Cayman Islands",
          "CF" => "Central African Republic",
          "TD" => "Chad",
          "CL" => "Chile",
          "CN" => "China",
          "CX" => "Christmas Island",
          "CC" => "Cocos (Keeling) Islands",
          "CO" => "Colombia",
          "KM" => "Comoros",
          "CG" => "Congo",
          "CD" => "Congo, Democratic Republic of the Congo",
          "CK" => "Cook Islands",
          "CR" => "Costa Rica",
          "CI" => "Cote D'Ivoire",
          "HR" => "Croatia",
          "CU" => "Cuba",
          "CW" => "Curacao",
          "CY" => "Cyprus",
          "CZ" => "Czech Republic",
          "DK" => "Denmark",
          "DJ" => "Djibouti",
          "DM" => "Dominica",
          "DO" => "Dominican Republic",
          "EC" => "Ecuador",
          "EG" => "Egypt",
          "SV" => "El Salvador",
          "GQ" => "Equatorial Guinea",
          "ER" => "Eritrea",
          "EE" => "Estonia",
          "ET" => "Ethiopia",
          "FK" => "Falkland Islands (Malvinas)",
          "FO" => "Faroe Islands",
          "FJ" => "Fiji",
          "FI" => "Finland",
          "FR" => "France",
          "GF" => "French Guiana",
          "PF" => "French Polynesia",
          "TF" => "French Southern Territories",
          "GA" => "Gabon",
          "GM" => "Gambia",
          "GE" => "Georgia",
          "DE" => "Germany",
          "GH" => "Ghana",
          "GI" => "Gibraltar",
          "GR" => "Greece",
          "GL" => "Greenland",
          "GD" => "Grenada",
          "GP" => "Guadeloupe",
          "GU" => "Guam",
          "GT" => "Guatemala",
          "GG" => "Guernsey",
          "GN" => "Guinea",
          "GW" => "Guinea-Bissau",
          "GY" => "Guyana",
          "HT" => "Haiti",
          "HM" => "Heard Island and Mcdonald Islands",
          "VA" => "Holy See (Vatican City State)",
          "HN" => "Honduras",
          "HK" => "Hong Kong",
          "HU" => "Hungary",
          "IS" => "Iceland",
          "IN" => "India",
          "ID" => "Indonesia",
          "IR" => "Iran, Islamic Republic of",
          "IQ" => "Iraq",
          "IE" => "Ireland",
          "IM" => "Isle of Man",
          "IL" => "Israel",
          "IT" => "Italy",
          "JM" => "Jamaica",
          "JP" => "Japan",
          "JE" => "Jersey",
          "JO" => "Jordan",
          "KZ" => "Kazakhstan",
          "KE" => "Kenya",
          "KI" => "Kiribati",
          "KP" => "Korea, Democratic People's Republic of",
          "KR" => "Korea, Republic of",
          "XK" => "Kosovo",
          "KW" => "Kuwait",
          "KG" => "Kyrgyzstan",
          "LA" => "Lao People's Democratic Republic",
          "LV" => "Latvia",
          "LB" => "Lebanon",
          "LS" => "Lesotho",
          "LR" => "Liberia",
          "LY" => "Libyan Arab Jamahiriya",
          "LI" => "Liechtenstein",
          "LT" => "Lithuania",
          "LU" => "Luxembourg",
          "MO" => "Macao",
          "MK" => "Macedonia, the Former Yugoslav Republic of",
          "MG" => "Madagascar",
          "MW" => "Malawi",
          "MY" => "Malaysia",
          "MV" => "Maldives",
          "ML" => "Mali",
          "MT" => "Malta",
          "MH" => "Marshall Islands",
          "MQ" => "Martinique",
          "MR" => "Mauritania",
          "MU" => "Mauritius",
          "YT" => "Mayotte",
          "MX" => "Mexico",
          "FM" => "Micronesia, Federated States of",
          "MD" => "Moldova, Republic of",
          "MC" => "Monaco",
          "MN" => "Mongolia",
          "ME" => "Montenegro",
          "MS" => "Montserrat",
          "MA" => "Morocco",
          "MZ" => "Mozambique",
          "MM" => "Myanmar",
          "NA" => "Namibia",
          "NR" => "Nauru",
          "NP" => "Nepal",
          "NL" => "Netherlands",
          "AN" => "Netherlands Antilles",
          "NC" => "New Caledonia",
          "NZ" => "New Zealand",
          "NI" => "Nicaragua",
          "NE" => "Niger",
          "NG" => "Nigeria",
          "NU" => "Niue",
          "NF" => "Norfolk Island",
          "MP" => "Northern Mariana Islands",
          "NO" => "Norway",
          "OM" => "Oman",
          "PK" => "Pakistan",
          "PW" => "Palau",
          "PS" => "Palestinian Territory, Occupied",
          "PA" => "Panama",
          "PG" => "Papua New Guinea",
          "PY" => "Paraguay",
          "PE" => "Peru",
          "PH" => "Philippines",
          "PN" => "Pitcairn",
          "PL" => "Poland",
          "PT" => "Portugal",
          "PR" => "Puerto Rico",
          "QA" => "Qatar",
          "RE" => "Reunion",
          "RO" => "Romania",
          "RU" => "Russian Federation",
          "RW" => "Rwanda",
          "BL" => "Saint Barthelemy",
          "SH" => "Saint Helena",
          "KN" => "Saint Kitts and Nevis",
          "LC" => "Saint Lucia",
          "MF" => "Saint Martin",
          "PM" => "Saint Pierre and Miquelon",
          "VC" => "Saint Vincent and the Grenadines",
          "WS" => "Samoa",
          "SM" => "San Marino",
          "ST" => "Sao Tome and Principe",
          "SA" => "Saudi Arabia",
          "SN" => "Senegal",
          "RS" => "Serbia",
          "CS" => "Serbia and Montenegro",
          "SC" => "Seychelles",
          "SL" => "Sierra Leone",
          "SG" => "Singapore",
          "SX" => "Sint Maarten",
          "SK" => "Slovakia",
          "SI" => "Slovenia",
          "SB" => "Solomon Islands",
          "SO" => "Somalia",
          "ZA" => "South Africa",
          "GS" => "South Georgia and the South Sandwich Islands",
          "SS" => "South Sudan",
          "ES" => "Spain",
          "LK" => "Sri Lanka",
          "SD" => "Sudan",
          "SR" => "Suriname",
          "SJ" => "Svalbard and Jan Mayen",
          "SZ" => "Swaziland",
          "SE" => "Sweden",
          "CH" => "Switzerland",
          "SY" => "Syrian Arab Republic",
          "TW" => "Taiwan, Province of China",
          "TJ" => "Tajikistan",
          "TZ" => "Tanzania, United Republic of",
          "TH" => "Thailand",
          "TL" => "Timor-Leste",
          "TG" => "Togo",
          "TK" => "Tokelau",
          "TO" => "Tonga",
          "TT" => "Trinidad and Tobago",
          "TN" => "Tunisia",
          "TR" => "Turkey",
          "TM" => "Turkmenistan",
          "TC" => "Turks and Caicos Islands",
          "TV" => "Tuvalu",
          "UG" => "Uganda",
          "UA" => "Ukraine",
          "AE" => "United Arab Emirates",
          "GB" => "United Kingdom",
          "US" => "United States",
          "UM" => "United States Minor Outlying Islands",
          "UY" => "Uruguay",
          "UZ" => "Uzbekistan",
          "VU" => "Vanuatu",
          "VE" => "Venezuela",
          "VN" => "Viet Nam",
          "VG" => "Virgin Islands, British",
          "VI" => "Virgin Islands, U.s.",
          "WF" => "Wallis and Futuna",
          "EH" => "Western Sahara",
          "YE" => "Yemen",
          "ZM" => "Zambia",
          "ZW" => "Zimbabwe"
      );
      $country = ucwords($country);
      return array_search($country, $countries_list);
  }
}

endif;