
if (typeof ananlytics != undefined) {
  analytics.ready(function() {
    cdpIds = {
      "anonymous_id": analytics.user().anonymousId(),
      "user_id": analytics.user().id()
    };

    jQuery(("input[data-cdp-analytics='identity']")).val(JSON.stringify(cdpIds));
  });
}