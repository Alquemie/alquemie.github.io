<?php return array (
  'root' => 
  array (
    'pretty_version' => 'dev-master',
    'version' => 'dev-master',
    'aliases' => 
    array (
    ),
    'reference' => '9e12f9459ccf78d4dc6e21a0e5224d250ac627a1',
    'name' => '__root__',
  ),
  'versions' => 
  array (
    '__root__' => 
    array (
      'pretty_version' => 'dev-master',
      'version' => 'dev-master',
      'aliases' => 
      array (
      ),
      'reference' => '9e12f9459ccf78d4dc6e21a0e5224d250ac627a1',
    ),
    'stripe/stripe-php' => 
    array (
      'pretty_version' => 'v7.77.0',
      'version' => '7.77.0.0',
      'aliases' => 
      array (
      ),
      'reference' => 'f6724447481f6fb8c2e714165e092adad9ca470a',
    ),
  ),
);
