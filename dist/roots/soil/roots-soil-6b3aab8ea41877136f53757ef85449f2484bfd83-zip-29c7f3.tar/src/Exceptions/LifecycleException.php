<?php

namespace Roots\Soil\Exceptions;

use Exception;

class LifecycleException extends Exception
{
    //
}
