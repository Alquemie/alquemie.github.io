<?php
/**
 * Plugin Name: UwU
 * Version: 1.0.0
 */

define('fake_UwU', 'loaded');
